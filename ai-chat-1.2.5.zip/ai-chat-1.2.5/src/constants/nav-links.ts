export const navLinks: Record<string, string> = {
  features: "#features",
  extension: "https://chromewebstore.google.com/detail/ai-chat/edlcpchefdlohaedkcgffdakmflpfpnd"
};
