// From https://github.com/Achaak/react-os-icons/

export interface SVGComponent {
  className?: string,
  height?: number | string,
  width?: number | string,
  style?: React.CSSProperties,
}
