# Privacy Policy

## AI Chat

The AI Chat desktop application does not collect any personal information.

## Website

The [AI Chat website](https://www.chatbar.top) uses [Google Analytics](https://analytics.google.com) to collect anonymous information about website usage.

## Contact

Please do not hesitate to [contact us](https://github.com/rabrain/ai-chat/discussions) for questions about this privacy policy.
